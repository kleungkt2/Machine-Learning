Name: Leung Ko Tsun SID: T10902303
partA: put input data in "Aberdeen" folder(or change the path if you wish) \
partB: put trainX.npy, visualization.npy, model_ae_best.pkl(link on report) on the same directory of this folder \ 
then run partB_test.py -> for submission.csv
or run partB_plot.py -> for graphs used in report